package com.org.speakout;

import android.os.Bundle;

import com.wisdomrider.Activities.BaseActivity;

public class HomePageActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

}

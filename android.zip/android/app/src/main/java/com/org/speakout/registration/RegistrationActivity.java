package com.org.speakout.registration;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.org.speakout.R;
import com.org.speakout.base.BaseActivity;

public class RegistrationActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
    }
}

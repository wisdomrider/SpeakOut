package com.org.speakout.constance;

public class AppConstance {
    public static  final int SPLASH_DISPLAY_LENGTH = 1000;
}

package com.org.speakout.base;


import android.os.Bundle;

public class BaseActivity extends com.wisdomrider.Activities.BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
